﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProcessLimiter
{
    class ProcessLimit
    {
        public string ProcessName { get; set; }

        public string StartTime { get; set; }

        public string EndTime { get; set; }

        public string WeeklyLimit { get; set; }
    }

    
}
