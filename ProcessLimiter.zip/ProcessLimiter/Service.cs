﻿using Microsoft.Extensions.PlatformAbstractions;
using PeterKottas.DotNetCore.WindowsService.Base;
using PeterKottas.DotNetCore.WindowsService.Interfaces;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Data;
using System.Data.SqlClient;

namespace ProcessLimiter
{
    public class Service : MicroService, IMicroService
    {
        private IMicroServiceController controller;

        public Service()
        {
            controller = null;
        }

        public Service(IMicroServiceController controller)
        {
            this.controller = controller;
        }

        List<ProcessLimit> _processLimits = new List<ProcessLimit>();
        SqlConnection _connection = new SqlConnection("data source=.;initial catalog=ProcessLimiter;user id=sa;password=123;");

        public void Start()
        {


            StartBase();

            string processLimitsFileName = Path.Combine(PlatformServices.Default.Application.ApplicationBasePath, "ProcessLimits.txt");
            string[] processLimitLine;
            string line;

            using (StreamReader stream = File.OpenText(processLimitsFileName))
            {
                while ((line = stream.ReadLine()) != null)
                {
                    if (line.Substring(0,2).Equals("--"))
                        continue;

                    processLimitLine = line.Split('-');

                    _processLimits.Add(new ProcessLimit
                    {
                        ProcessName = processLimitLine[0],
                        StartTime = processLimitLine[1],
                        EndTime = processLimitLine[2],
                        WeeklyLimit = processLimitLine[3]
                    });
                }
            }


            Timers.Start("Poller", 1000 * 10, () =>
            {
                Process[] Processes = Process.GetProcesses();

                foreach (Process p in Processes)
                {
                    foreach (ProcessLimit pl in _processLimits)
                    {
                        string processName = pl.ProcessName;
                        DateTime startTime = DateTime.Parse( DateTime.Today.ToString("MM/dd/yyyy") + " " + pl.StartTime + ":00");
                        DateTime endTime = DateTime.Parse(DateTime.Today.ToString("MM/dd/yyyy") + " " + pl.EndTime + ":00");

                        string[] weeklyLimits = pl.WeeklyLimit.Split(":");

                        int WeeklyLimitSeconds = (Int32.Parse(weeklyLimits[0]) * 3600) + (Int32.Parse(weeklyLimits[1]) * 60);

                        if (p.ProcessName.Equals(processName))
                        { 
                            if (!(DateTime.Now >= startTime && DateTime.Now <= endTime))
                            {
                                p.Kill();
                            }
                            else if(WeeklyLimitSeconds != 0)
                            {
                                int result ;
                                using (var command = _connection.CreateCommand())
                                {
                                    command.CommandType = CommandType.StoredProcedure;
                                    command.CommandText = "CheckProcessWeeklyLimit";
                                    command.Parameters.AddWithValue("@ProcessName", pl.ProcessName);
                                    command.Parameters.AddWithValue("@WeeklyLimitSeconds", WeeklyLimitSeconds);
                                    command.Parameters.Add("@Result", SqlDbType.Int).Direction = ParameterDirection.Output;
                                    _connection.Open();
                                    command.ExecuteNonQuery();
                                    result = Int32.Parse(command.Parameters["@Result"].Value.ToString() );
                                    _connection.Close();
                                }
                                if (result < 0)
                                {
                                    p.Kill();
                                }

                            }
                        }
                    }

                }


            },
            (e) =>
            {
                Console.WriteLine("Exception while polling: {0}\n", e.ToString());
            });
            Console.WriteLine("I started");


        }

        public void Stop()
        {
            this.StopBase();
            Console.WriteLine("I stopped");
        }
    }
}
